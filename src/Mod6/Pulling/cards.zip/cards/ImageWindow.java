package cards;
import javax.swing.*;
import java.awt.*;

/**
 *Draw images from picture files
 * from Cate Anderson
 */

public class ImageWindow extends JFrame{

	private int win_width = 500;
	private int win_height = 500;
	private ImageDisplay panel;

	public ImageWindow(){
		this.setTitle("Exercise  Window"); 
		this.setSize(win_width,win_height); 
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		inititalizeWindow();
		this.setVisible(true); 
	}

	public void inititalizeWindow()
	{
		panel = new ImageDisplay();
		this.add(panel, BorderLayout.CENTER);
	}


	public static void main(String[] args)
	{
		ImageWindow ew = new ImageWindow();
	}

}
